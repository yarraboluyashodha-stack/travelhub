<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Destinations - Travel & Tourism</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">

    <div class="container">

        <a class="navbar-brand" href="index.php">
            🌍 Travel & Tourism
        </a>

        <div class="collapse navbar-collapse">

            <ul class="navbar-nav ms-auto">

                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" href="destinations.php">
                        Destinations
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
                <li>
                    <a  class="nav-link" href="login.php">
                    Login
                     </a>
                 </li>

                
                
                <li class="nav-item">
                        <a class="nav-link" href="enquiry.php">
                            Register
                        </a>
                    </li>
                <li class="nav-item">
                        <a class="nav-link" href="saved_trips.php">My Saved Trips

                        </a>
                    </li>

            </ul>

        </div>

    </div>

</nav>


<!-- DESTINATIONS -->

<section class="container py-5">

    <h1 class="text-center mb-4">
        Explore Our Destinations 🌍
    </h1>

    <p class="text-center mb-5">
        Discover beautiful countries and amazing tourist places around the world.
    </p>


    <div class="row g-4">


        <!-- INDIA -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/india.jpg"
                     class="card-img-top"
                     alt="India">

                <div class="card-body">

                    <h4 class="card-title">
                        India 🇮🇳
                    </h4>

                    <p class="card-text">
                        Explore India's beautiful culture,
                        heritage and famous tourist places.
                    </p>

                   <a href="country_details.php?id=1">
    View Details
</a>

                </div>

            </div>

        </div>


        <!-- JAPAN -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/japan.jpg"
                     class="card-img-top"
                     alt="Japan">

                <div class="card-body">

                    <h4 class="card-title">
                        Japan 🇯🇵
                    </h4>

                    <p class="card-text">
                        Experience Japan's unique culture,
                        technology and beautiful places.
                    </p>

                 <a href="country_details.php?id=2">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- FRANCE -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/france.jpg"
                     class="card-img-top"
                     alt="France">

                <div class="card-body">

                    <h4 class="card-title">
                        France 🇫🇷
                    </h4>

                    <p class="card-text">
                        Visit famous landmarks and enjoy
                        the beauty of France.
                    </p>

                   
                    <a href="country_details.php?id=3">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- ITALY -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/italy.jpg"
                     class="card-img-top"
                     alt="Italy">

                <div class="card-body">

                    <h4 class="card-title">
                        Italy 🇮🇹
                    </h4>

                    <p class="card-text">
                        Explore Italy's history, architecture,
                        art and delicious food.
                    </p>

                    <a href="country_details.php?id=4">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- SWITZERLAND -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/switzerland.jpg"
                     class="card-img-top"
                     alt="Switzerland">

                <div class="card-body">

                    <h4 class="card-title">
                        Switzerland 🇨🇭
                    </h4>

                    <p class="card-text">
                        Enjoy beautiful mountains,
                        lakes and peaceful scenery.
                    </p>

                   <a href="country_details.php?id=5">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- AUSTRALIA -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/australia.jpg"
                     class="card-img-top"
                     alt="Australia">

                <div class="card-body">

                    <h4 class="card-title">
                        Australia 🇦🇺
                    </h4>

                    <p class="card-text">
                        Discover beaches, wildlife,
                        nature and modern cities.
                    </p>

                    <a href="country_details.php?id=6">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- UNITED KINGDOM -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/uk.jpg"
                     class="card-img-top"
                     alt="United Kingdom">

                <div class="card-body">

                    <h4 class="card-title">
                        United Kingdom 🇬🇧
                    </h4>

                    <p class="card-text">
                        Explore historic buildings,
                        royal palaces and beautiful cities.
                    </p>

                    <a href="country_details.php?id=7">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- DUBAI -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/dubai.jpg"
                     class="card-img-top"
                     alt="Dubai">

                <div class="card-body">

                    <h4 class="card-title">
                        Dubai 🇦🇪
                    </h4>

                    <p class="card-text">
                        Experience luxury, modern buildings,
                        shopping and desert adventures.
                    </p>

                    <a href="country_details.php?id=8">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- SINGAPORE -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/singapore.jpg"
                     class="card-img-top"
                     alt="Singapore">

                <div class="card-body">

                    <h4 class="card-title">
                        Singapore 🇸🇬
                    </h4>

                    <p class="card-text">
                        Discover beautiful gardens,
                        shopping and modern attractions.
                    </p>

                    <a href="country_details.php?id=9">
    View Details
</a>
                </div>

            </div>

        </div>


        <!-- THAILAND -->

        <div class="col-md-4">

            <div class="card h-100 shadow">

                <img src="images/thailand.jpg"
                     class="card-img-top"
                     alt="Thailand">

                <div class="card-body">

                    <h4 class="card-title">
                        Thailand 🇹🇭
                    </h4>

                    <p class="card-text">
                        Explore beautiful beaches,
                        islands, temples and Thai culture.
                    </p>

                    <a href="country_details.php?id=10">
    View Details
</a>
                </div>

            </div>

        </div>


    </div>

</section>


<!-- FOOTER -->

<footer class="bg-dark text-white text-center p-3">

    <p class="mb-0">
        © 2026 Travel & Tourism | All Rights Reserved
    </p>

</footer>

</body>

</html>