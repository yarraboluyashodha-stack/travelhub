<?php

$folder = "saved_trips/";

$trips = [];

if (is_dir($folder)) {

    $files = scandir($folder);

    foreach ($files as $file) {

        if (pathinfo($file, PATHINFO_EXTENSION) === "html") {

            $trips[] = $file;
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Saved Trips</title>

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    font-family: Arial, sans-serif;

    background: #f4f7fb;

}


/* HEADER */

.header {

    background: linear-gradient(135deg, #007bff, #00b4d8);

    color: white;

    text-align: center;

    padding: 45px 20px;
}

.header h1 {

    margin: 0;

    font-size: 42px;
}

.header p {

    font-size: 18px;
}


/* CONTAINER */

.container {

    width: 90%;

    max-width: 1100px;

    margin: 40px auto;
}


/* GRID */

.trips {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 25px;
}


/* CARD */

.card {

    background: white;

    padding: 25px;

    border-radius: 15px;

    box-shadow:
        0 5px 20px rgba(0,0,0,0.1);

    text-align: center;

    transition: 0.3s;
}

.card:hover {

    transform: translateY(-5px);

    box-shadow:
        0 10px 25px rgba(0,0,0,0.15);
}

.card h2 {

    color: #007bff;

    font-size: 22px;

    margin-bottom: 15px;
}

.card p {

    color: #666;

    margin-bottom: 20px;
}


/* BUTTON */

.view-btn {

    display: inline-block;

    padding: 12px 25px;

    background: #007bff;

    color: white;

    text-decoration: none;

    border-radius: 8px;

    transition: 0.3s;
}

.view-btn:hover {

    background: #0056b3;
}


/* EMPTY */

.empty {

    background: white;

    padding: 50px;

    text-align: center;

    border-radius: 15px;

    box-shadow:
        0 5px 20px rgba(0,0,0,0.08);
}

.empty h2 {

    color: #007bff;
}


/* BACK */

.back {

    text-align: center;

    margin-top: 40px;
}

.back a {

    display: inline-block;

    padding: 12px 25px;

    background: #555;

    color: white;

    text-decoration: none;

    border-radius: 8px;
}


/* MOBILE */

@media(max-width: 800px) {

    .trips {

        grid-template-columns: 1fr;
    }

    .header h1 {

        font-size: 32px;
    }

}

</style>

</head>


<body>


<div class="header">

    <h1>📂 My Saved Trips</h1>

    <p>
        Your personalized travel plans
    </p>

</div>


<div class="container">


<?php if (count($trips) > 0): ?>


<div class="trips">


<?php foreach ($trips as $trip): ?>


<div class="card">


<h2>
    ✈️ Saved Trip
</h2>


<p>

<?php

$date = pathinfo($trip, PATHINFO_FILENAME);

$date = str_replace("trip_", "", $date);

echo "Created: " . $date;

?>

</p>


<a
    href="<?php echo $folder . urlencode($trip); ?>"
    target="_blank"
    class="view-btn"
>
    👁️ View Trip
</a>


</div>


<?php endforeach; ?>


</div>


<?php else: ?>


<div class="empty">

    <h2>
        📭 No Saved Trips Yet
    </h2>

    <p>
        Create your first personalized trip plan!
    </p>

</div>


<?php endif; ?>


<div class="back">

    <a href="destinations.php">
        ← Explore Destinations
    </a>

</div>


</div>


</body>

</html>