<?php
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $destination = trim($_POST["destination"]);
    $travel_date = trim($_POST["travel_date"]);
    $people = trim($_POST["people"]);
    $user_message = trim($_POST["message"]);

    if (
        empty($name) ||
        empty($email) ||
        empty($phone) ||
        empty($destination) ||
        empty($travel_date) ||
        empty($people)
    ) {
        $message = "Please fill all required fields.";
    } else {
        $message = "Thank you, $name! Your enquiry has been submitted successfully.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Enquiry - Travel Hub</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>

        body {
            margin: 0;
            background-color: #f5f9ff;
            font-family: Arial, sans-serif;
        }

        /* Navbar */

        .navbar {
            padding: 15px ;
        }

        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
        }

        .menu {
            display: flex;
            flex-direction: row;
            align-items: center;
            margin-left: auto;
        }

        .menu a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-size: 16px;
        }

        /* Enquiry Section */

        .enquiry-section {
            padding: 60px 20px;
        }

        .enquiry-box {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.10);
        }

        .enquiry-box h1 {
            text-align: center;
            color: #0d6efd;
            margin-bottom: 30px;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control,
        .form-select {
            margin-bottom: 18px;
        }

        .submit-btn {
            width: 100%;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
        }

        .success-message {
            background-color: #d1e7dd;
            color: #0f5132;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }

        @media (max-width: 768px) {

            .menu {
                flex-wrap: wrap;
                justify-content: center;
                margin-top: 10px;
            }

            .menu a {
                margin: 5px 10px;
            }

            .enquiry-box {
                padding: 25px;
            }
        }

    </style>

</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">

    <div class="container">

        <a class="navbar-brand" href="index.php">
            🌍 Travel & Tourism
        </a>

        <div class="collapse navbar-collapse">

            <ul class="navbar-nav ms-auto">

                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link " href="destinations.php">
                        Destinations
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                
                
                <li class="nav-item">
                        <a class="nav-link active" href="enquiry.php">
                            Register
                        </a>
                    </li>
                <li class="nav-item">
                        <a class="nav-link" href="saved_trips.php">My Saved Trips

                        </a>
                    </li>

            </ul>

        </div>

    </div>

</nav>


    <!-- Enquiry Form -->

    <section class="enquiry-section">

        <div class="enquiry-box">

            <h1>Register For The Trip ✈️</h1>

            <?php if (!empty($message)) { ?>

                <div class="success-message">
                    <?php echo htmlspecialchars($message); ?>
                </div>

            <?php } ?>


            <form method="POST" action="enquiry.php">

                <!-- Name -->

                <label class="form-label">
                    Full Name
                </label>

                <input
                    type="text"
                    name="name"
                    class="form-control"
                    placeholder="Enter your name"
                    required
                >


                <!-- Email -->

                <label class="form-label">
                    Email
                </label>

                <input
                    type="email"
                    name="email"
                    class="form-control"
                    placeholder="Enter your email"
                    required
                >


                <!-- Phone -->

                <label class="form-label">
                    Phone Number
                </label>

                <input
                    type="tel"
                    name="phone"
                    class="form-control"
                    placeholder="Enter your phone number"
                    required
                >


                <!-- Destination -->

                <label class="form-label">
                    Select Destination
                </label>

                <select name="destination" class="form-select" required>

                    <option value="">-- Select Destination --</option>

                    <option value="India">India 🇮🇳</option>

                    <option value="Japan">Japan 🇯🇵</option>

                    <option value="France">France 🇫🇷</option>

                    <option value="Italy">Italy 🇮🇹</option>

                    <option value="UK">UK 🇬🇧</option>

                </select>


                <!-- Travel Date -->

                <label class="form-label">
                    Travel Date
                </label>

                <input
                    type="date"
                    name="travel_date"
                    class="form-control"
                    required
                >


                <!-- Number of People -->

                <label class="form-label">
                    Number of People
                </label>

                <input
                    type="number"
                    name="people"
                    class="form-control"
                    min="1"
                    placeholder="Enter number of people"
                    required
                >


                <!-- Message -->

                <label class="form-label">
                    Your Message
                </label>

                <textarea
                    name="message"
                    class="form-control"
                    rows="5"
                    placeholder="Enter your enquiry or requirements..."
                ></textarea>


                <!-- Submit -->

                <button
                    type="submit"
                    class="btn btn-primary submit-btn">
                    Submit 
                </button>

            </form>

        </div>

    </section>

</body>

</html>