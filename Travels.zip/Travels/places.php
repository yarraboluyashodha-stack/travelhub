<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Tourist Places</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Our CSS -->
    <link rel="stylesheet"
          href="css/style.css">

</head>

<body>

<!-- Navbar -->

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">

    <div class="container">

        <a class="navbar-brand"
           href="index.php">

            🌍 Travel & Tourism

        </a>

        <div>

            <a href="index.php"
               class="btn btn-light me-2">

                Home

            </a>

            <a href="destinations.php"
               class="btn btn-light">

                Destinations

            </a>

        </div>

    </div>

</nav>


<!-- Page Heading -->

<div class="container py-5">

    <h1 class="text-center mb-5">
        Famous Tourist Places 📍
    </h1>


    <div class="row">


        <!-- Taj Mahal -->

        <div class="col-md-4 mb-4">

            <div class="card h-100">

                <img src="images/tajmahal.jpg"
                     class="card-img-top"
                     alt="Taj Mahal">

                <div class="card-body">

                    <h3 class="card-title">
                        Taj Mahal
                    </h3>

                    <p class="card-text">

                        The Taj Mahal is one of India's
                        most famous historical monuments
                        located in Agra.

                    </p>

                    <p>
                        📍 Agra, India
                    </p>

                </div>

            </div>

        </div>


        <!-- Goa -->

        <div class="col-md-4 mb-4">

            <div class="card h-100">

                <img src="images/goa.jpg"
                     class="card-img-top"
                     alt="Goa">

                <div class="card-body">

                    <h3 class="card-title">
                        Goa
                    </h3>

                    <p class="card-text">

                        Goa is famous for beautiful beaches,
                        nature, food and nightlife.

                    </p>

                    <p>
                        📍 Goa, India
                    </p>

                </div>

            </div>

        </div>


        <!-- Kerala -->

        <div class="col-md-4 mb-4">

            <div class="card h-100">

                <img src="images/kerala.jpg"
                     class="card-img-top"
                     alt="Kerala">

                <div class="card-body">

                    <h3 class="card-title">
                        Kerala
                    </h3>

                    <p class="card-text">

                        Kerala is known for backwaters,
                        beaches, hills and beautiful nature.

                    </p>

                    <p>
                        📍 Kerala, India
                    </p>

                </div>

            </div>

        </div>


        <!-- Jaipur -->

        <div class="col-md-4 mb-4">

            <div class="card h-100">

                <img src="images/jaipur.jpg"
                     class="card-img-top"
                     alt="Jaipur">

                <div class="card-body">

                    <h3 class="card-title">
                        Jaipur
                    </h3>

                    <p class="card-text">

                        Jaipur is famous for its palaces,
                        forts and rich cultural heritage.

                    </p>

                    <p>
                        📍 Rajasthan, India
                    </p>

                </div>

            </div>

        </div>


        <!-- Kashmir -->

        <div class="col-md-4 mb-4">

            <div class="card h-100">

                <img src="images/kashmir.jpg"
                     class="card-img-top"
                     alt="Kashmir">

                <div class="card-body">

                    <h3 class="card-title">
                        Kashmir
                    </h3>

                    <p class="card-text">

                        Kashmir is known for mountains,
                        lakes and beautiful landscapes.

                    </p>

                    <p>
                        📍 Kashmir, India
                    </p>

                </div>

            </div>

        </div>


        <!-- Mumbai -->

        <div class="col-md-4 mb-4">

            <div class="card h-100">

                <img src="images/mumbai.jpg"
                     class="card-img-top"
                     alt="Mumbai">

                <div class="card-body">

                    <h3 class="card-title">
                        Mumbai
                    </h3>

                    <p class="card-text">

                        Mumbai is a major city famous for
                        Gateway of India and Marine Drive.

                    </p>

                    <p>
                        📍 Mumbai, India
                    </p>

                </div>

            </div>

        </div>


    </div>

</div>


<!-- Footer -->

<footer class="bg-dark text-white text-center p-3">

    © 2026 Travel & Tourism

</footer>


<!-- Bootstrap JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>

</html>