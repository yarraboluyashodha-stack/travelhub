<?php
include 'db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $destination = $_POST['destination'];
    $travel_date = $_POST['travel_date'];
    $people = $_POST['people'];
    $message_text = $_POST['message'];

    $sql = "INSERT INTO bookings
            (name, email, phone, destination, travel_date, people, message)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "sssssis",
        $name,
        $email,
        $phone,
        $destination,
        $travel_date,
        $people,
        $message_text
    );

    if ($stmt->execute()) {
        $message = "Booking submitted successfully!";
    } else {
        $message = "Something went wrong. Please try again.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Booking - Travel & Tourism</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">

            <a class="navbar-brand" href="index.php">
                🌍 Travel & Tourism
            </a>

            <div>
                <a class="btn btn-light me-2" href="index.php">Home</a>
                <a class="btn btn-light" href="destinations.php">Destinations</a>
            </div>

        </div>
    </nav>


    <!-- Booking Form -->
    <div class="container py-5">

        <h1 class="text-center mb-4">
            Book Your Trip ✈️
        </h1>

        <?php if ($message != ""): ?>

            <div class="alert alert-success text-center">
                <?php echo $message; ?>
            </div>

        <?php endif; ?>


        <div class="card mx-auto p-4" style="max-width: 650px;">

            <form method="POST" action="booking.php">

                <div class="mb-3">
                    <label class="form-label">Name</label>

                    <input type="text"
                           name="name"
                           class="form-control"
                           required>
                </div>


                <div class="mb-3">
                    <label class="form-label">Email</label>

                    <input type="email"
                           name="email"
                           class="form-control"
                           required>
                </div>


                <div class="mb-3">
                    <label class="form-label">Phone</label>

                    <input type="tel"
                           name="phone"
                           class="form-control"
                           required>
                </div>


                <div class="mb-3">
                    <label class="form-label">Destination</label>

                    <select name="destination"
                            class="form-select"
                            required>

                        <option value="">Select Destination</option>
                        <option value="India">India</option>
                        <option value="Japan">Japan</option>
                        <option value="France">France</option>
                        <option value="Dubai">Dubai</option>
                        <option value="Switzerland">Switzerland</option>

                    </select>
                </div>


                <div class="mb-3">
                    <label class="form-label">Travel Date</label>

                    <input type="date"
                           name="travel_date"
                           class="form-control"
                           required>
                </div>


                <div class="mb-3">
                    <label class="form-label">Number of People</label>

                    <input type="number"
                           name="people"
                           class="form-control"
                           min="1"
                           required>
                </div>


                <div class="mb-3">
                    <label class="form-label">Message</label>

                    <textarea name="message"
                              class="form-control"
                              rows="4"
                              placeholder="Any special requirements?"></textarea>
                </div>


                <button type="submit"
                        class="btn btn-primary w-100">
                    Submit Booking
                </button>

            </form>

        </div>

    </div>


    <footer class="bg-dark text-white text-center p-3">
        © 2026 Travel & Tourism
    </footer>

</body>
</html>