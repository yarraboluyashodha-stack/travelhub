<?php  
include 'db.php';  
  
$message = "";  
$error = "";  
  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
  
    $name = trim($_POST["name"]);  
    $email = trim($_POST["email"]);  
    $password = $_POST["password"];  
    $confirm_password = $_POST["confirm_password"];  
  
    if ($password !== $confirm_password) {  
  
        $error = "Passwords do not match!";  
  
    } else {  
  
        // Check whether email already exists  
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");  
        $check->bind_param("s", $email);  
        $check->execute();  
        $check->store_result();  
  
        if ($check->num_rows > 0) {  
  
            $error = "Email already registered!";  
  
        } else {  
  
            // Securely hash the password  
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);  
  
            $sql = "INSERT INTO users (name, email, password)  
                    VALUES (?, ?, ?)";  
  
            $stmt = $conn->prepare($sql);  
            $stmt->bind_param(  
                "sss",  
                $name,  
                $email,  
                $hashed_password  
            );  
  
            if ($stmt->execute()) {  
                $message = "Registration successful! You can login now.";  
            } else {  
                $error = "Registration failed. Please try again.";  
            }  
  
            $stmt->close();  
        }  
  
        $check->close();  
    }  
}  
?>  <!DOCTYPE html>  <html lang="en">  <head>  <meta charset="UTF-8">  

<meta name="viewport"  
      content="width=device-width, initial-scale=1.0">  

<title>Register - Travel & Tourism</title>  

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"  
      rel="stylesheet">  

<link rel="stylesheet"  
      href="css/style.css">

</head>  <body>  <div class="container">  <div class="card mx-auto mt-5 p-4"  
     style="max-width: 500px;">  

    <h2 class="text-center mb-4">  
        Create Account 👤  
    </h2>  

    <?php if ($message != "") { ?>  

        <div class="alert alert-success">  
            <?php echo $message; ?>  
        </div>  

    <?php } ?>  

    <?php if ($error != "") { ?>  

        <div class="alert alert-danger">  
            <?php echo $error; ?>  
        </div>  

    <?php } ?>  


    <form method="POST"  
          action="register.php">  

        <div class="mb-3">  

            <label class="form-label">  
                Full Name  
            </label>  

            <input type="text"  
                   name="name"  
                   class="form-control"  
                   required>  

        </div>  


        <div class="mb-3">  

            <label class="form-label">  
                Email  
            </label>  

            <input type="email"  
                   name="email"  
                   class="form-control"  
                   required>  

        </div>  


        <div class="mb-3">  

            <label class="form-label">  
                Password  
            </label>  

            <input type="password"  
                   name="password"  
                   class="form-control"  
                   minlength="6"  
                   required>  

        </div>  


        <div class="mb-3">  

            <label class="form-label">  
                Confirm Password  
            </label>  

            <input type="password"  
                   name="confirm_password"  
                   class="form-control"  
                   minlength="6"  
                   required>  

        </div>  


        <button type="submit"  
                class="btn btn-primary w-100">  

            Register  

        </button>  

    </form>  


    <p class="text-center mt-3">  

        Already have an account?  

        <a href="user_login.php">  
            Login  
        </a>  

    </p>  

</div>

</div>  </body>  
</html>