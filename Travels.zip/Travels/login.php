<?php

session_start();

include 'db.php';

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if (empty($email) || empty($password)) {

        $error = "Please enter email and password.";

    } else {

        $sql = "SELECT id, name, email, password FROM users WHERE email = ?";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows == 1) {

            $user = $result->fetch_assoc();

            if (password_verify($password, $user["password"])) {

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_name"] = $user["name"];
                $_SESSION["user_email"] = $user["email"];

                header("Location: index.php");
                exit();

            } else {

                $error = "Invalid email or password.";

            }

        } else {

            $error = "Invalid email or password.";

        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login - Travel Hub</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family: Arial, sans-serif;

    min-height: 100vh;

    background:
        linear-gradient(
            rgba(0, 123, 255, 0.65),
            rgba(0, 180, 216, 0.65)
        ),
        url("images/login.jpg");

    background-size: cover;

    background-position: center;

    display: flex;

    align-items: center;

    justify-content: center;

}


/* LOGIN BOX */

.login-container {

    width: 90%;

    max-width: 420px;

    background: white;

    padding: 40px;

    border-radius: 20px;

    box-shadow: 0 10px 35px rgba(0,0,0,0.25);

}


/* LOGO */

.logo {

    text-align: center;

    font-size: 32px;

    margin-bottom: 10px;

}

.login-title {

    text-align: center;

    color: #007bff;

    margin-bottom: 8px;

}

.login-subtitle {

    text-align: center;

    color: #777;

    margin-bottom: 30px;

}


/* ERROR */

.error {

    background: #ffe5e5;

    color: #d00000;

    padding: 12px;

    border-radius: 8px;

    text-align: center;

    margin-bottom: 20px;

}


/* INPUT */

.form-group {

    margin-bottom: 20px;

}

.form-group label {

    display: block;

    margin-bottom: 7px;

    font-weight: bold;

}

.form-group input {

    width: 100%;

    padding: 13px;

    border: 1px solid #ddd;

    border-radius: 8px;

    font-size: 16px;

    outline: none;

}

.form-group input:focus {

    border-color: #007bff;

    box-shadow: 0 0 5px rgba(0,123,255,0.2);

}


/* LOGIN BUTTON */

.login-btn {

    width: 100%;

    padding: 14px;

    border: none;

    border-radius: 9px;

    background: linear-gradient(
        135deg,
        #007bff,
        #00b4d8
    );

    color: white;

    font-size: 17px;

    font-weight: bold;

    cursor: pointer;

}

.login-btn:hover {

    opacity: 0.9;

}


/* REGISTER */

.register-text {

    text-align: center;

    margin-top: 25px;

    color: #666;

}

.register-text a {

    color: #007bff;

    text-decoration: none;

    font-weight: bold;

}


/* BACK */

.back {

    display: block;

    text-align: center;

    margin-top: 20px;

    color: #555;

    text-decoration: none;

}

</style>

</head>


<body>


<div class="login-container">


    <div class="logo">
        🌍
    </div>


    <h1 class="login-title">
        Welcome Back!
    </h1>


    <p class="login-subtitle">
        Login to continue your travel journey
    </p>


    <?php if (!empty($error)): ?>

        <div class="error">
            ❌ <?php echo htmlspecialchars($error); ?>
        </div>

    <?php endif; ?>


    <form method="POST">


        <div class="form-group">

            <label>
                📧 Email Address
            </label>

            <input
                type="email"
                name="email"
                placeholder="Enter your email"
                required
            >

        </div>


        <div class="form-group">

            <label>
                🔒 Password
            </label>

            <input
                type="password"
                name="password"
                placeholder="Enter your password"
                required
            >

        </div>


        <button
            type="submit"
            class="login-btn"
        >
            🔐 Login
        </button>


    </form>


    <p class="register-text">

        Don't have an account?

        <a href="register.php">
            Register Now
        </a>

    </p>


    <a href="index.php" class="back">
        ← Back to Home
    </a>


</div>


</body>

</html>