<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>About Us - Travel Hub</title>

<style>

/* ================= GENERAL ================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: Arial, sans-serif;
    background: #f5f9ff;
    color: #333;
}


/* ================= NAVIGATION ================= */

.navbar {
    width: 100%;
    height: 65px;

    background: linear-gradient(135deg, #007bff, #00b4d8);

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 6%;

    box-shadow: 0 3px 12px rgba(0,0,0,0.15);
}

.logo {
    color: white;
    font-size: 21px;
    font-weight: bold;
    text-decoration: none;
    white-space: nowrap;
}

.nav-links {
    display: flex;
    flex-direction: row;
    align-items: center;

    list-style: none;

    gap: 5px;

    margin: 0;
    padding: 0;
}

.nav-links li {
    display: block;
}

.nav-links a {
    display: block;

    color: white;
    text-decoration: none;

    font-size: 14px;
    font-weight: 600;

    padding: 7px 9px;

    border-radius: 5px;

    white-space: nowrap;

    transition: 0.2s;
}

.nav-links a:hover {
    color: #e8f7ff;
}

/* ONLY ABOUT HIGHLIGHT */

.nav-links a.active {
    color: white;
    background: transparent;
    font-weight: 800;
}


/* ================= HERO ================= */

.hero {

    height: 300px;

    background:
        linear-gradient(
            rgba(0, 80, 160, 0.55),
            rgba(0, 0, 0, 0.45)
        ),
        url("images/about.jpg");

    background-size: cover;
    background-position: center;

    display: flex;
    align-items: center;
    justify-content: center;

    text-align: center;

    color: white;

    padding: 20px;
}

.hero-content {
    max-width: 850px;
}

.hero h1 {
    font-size: 42px;
    margin: 0 0 8px 0;
}

.hero p {
    font-size: 18px;
    line-height: 1.4;
    margin: 0;
}


/* ================= CONTAINER ================= */

.container {
    width: 90%;
    max-width: 1100px;
    margin: auto;
}


/* ================= ALL SECTIONS ================= */

.section {
    padding: 22px 0;
    margin: 0;
}


/* ================= SECTION HEADINGS ================= */

.section-title {
    text-align: center;

    color: #007bff;

    font-size: 30px;

    margin: 0 0 6px 0;
}

.section-subtitle {
    text-align: center;

    color: #666;

    max-width: 750px;

    margin: 0 auto 18px auto;

    line-height: 1.5;
}


/* ================= MISSION ================= */

.mission-box {

    background: white;

    padding: 22px;

    border-radius: 15px;

    text-align: center;

    box-shadow: 0 5px 18px rgba(0,0,0,0.08);
}

.mission-box h2 {
    color: #007bff;
    margin: 0 0 8px 0;
}

.mission-box p {
    font-size: 16px;
    line-height: 1.6;
    color: #555;
    margin: 0;
}


/* ================= HOW IT WORKS ================= */

.steps {

    display: grid;

    grid-template-columns: repeat(5, 1fr);

    gap: 12px;
}

.step {

    background: white;

    padding: 18px 12px;

    text-align: center;

    border-radius: 12px;

    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.step-icon {
    font-size: 34px;
    margin-bottom: 7px;
}

.step h3 {
    color: #007bff;
    margin: 0 0 6px 0;
}

.step p {
    font-size: 13px;
    color: #666;
    line-height: 1.4;
    margin: 0;
}


/* ================= FEATURES ================= */

.features {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 12px;
}

.feature {

    background: white;

    padding: 20px 15px;

    text-align: center;

    border-radius: 12px;

    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.feature-icon {
    font-size: 36px;
    margin-bottom: 7px;
}

.feature h3 {
    color: #007bff;
    margin: 0 0 6px 0;
}

.feature p {
    color: #666;
    line-height: 1.4;
    font-size: 13px;
    margin: 0;
}


/* ================= HIGHLIGHTS ================= */

.highlights {

    background: linear-gradient(
        135deg,
        #007bff,
        #00b4d8
    );

    color: white;
}

.highlights .section-title {
    color: white;
}

.highlights .section-subtitle {
    color: white;
}

.highlight-grid {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 10px;
}

.highlight {

    text-align: center;

    padding: 15px;
}

.highlight-icon {
    font-size: 34px;
}

.highlight h3 {
    font-size: 27px;
    margin: 5px 0;
}

.highlight p {
    margin: 0;
}


/* ================= QUOTE ================= */

.quote {

    background: white;

    text-align: center;

    padding: 28px 20px;
}

.quote-text {

    max-width: 800px;

    margin: 0 auto;

    font-size: 22px;

    font-style: italic;

    color: #444;

    line-height: 1.5;
}

.quote-author {

    margin-top: 10px;

    color: #007bff;

    font-weight: bold;
}


/* ================= EXPLORE ================= */

.explore-section {

    text-align: center;

    background: linear-gradient(
        135deg,
        #007bff,
        #00b4d8
    );

    color: white;

    padding: 32px 20px;
}

.explore-section h2 {
    font-size: 30px;
    margin: 0 0 8px 0;
}

.explore-section p {

    font-size: 16px;

    line-height: 1.5;

    max-width: 700px;

    margin: 0 auto 18px auto;
}

.explore-btn {

    display: inline-block;

    padding: 11px 25px;

    background: white;

    color: #007bff;

    text-decoration: none;

    border-radius: 8px;

    font-size: 16px;

    font-weight: bold;
}

.explore-btn:hover {

    transform: translateY(-2px);

    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}


/* ================= FOOTER ================= */

.footer {

    background: #111827;

    color: white;

    text-align: center;

    padding: 15px;
}

.footer p {
    margin: 3px;
}


/* ================= TABLET ================= */

@media(max-width: 900px) {

    .navbar {
        padding: 0 3%;
    }

    .nav-links {
        gap: 2px;
    }

    .nav-links a {
        font-size: 12px;
        padding: 6px;
    }

    .steps {
        grid-template-columns: repeat(2, 1fr);
    }

    .features {
        grid-template-columns: repeat(2, 1fr);
    }

    .highlight-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}


/* ================= MOBILE ================= */

@media(max-width: 600px) {

    .navbar {

        height: auto;

        padding: 12px;

        flex-direction: column;

        gap: 10px;
    }

    .nav-links {

        flex-wrap: wrap;

        justify-content: center;
    }

    .hero {
        height: 260px;
    }

    .hero h1 {
        font-size: 32px;
    }

    .hero p {
        font-size: 16px;
    }

    .steps,
    .features,
    .highlight-grid {
        grid-template-columns: 1fr;
    }

}

</style>

</head>


<body>


<!-- ================= NAVIGATION ================= -->

<nav class="navbar">

    <a href="index.php" class="logo">
        🌍 Travel & Tourism
    </a>

    <ul class="nav-links">

        <li>
            <a href="index.php">
                Home
            </a>
        </li>

        <li>
            <a href="about.php" class="active">
                About
            </a>
        </li>

        <li>
            <a href="destinations.php">
                Destinations
            </a>
        </li>

        <li>
            <a href="contact.php">
                Contact
            </a>
        </li>
        <li>
            <a href="login.php">
            Login
        </a>
        </li>

        

        <li>
            <a href="enquiry.php">
                Register
            </a>
        </li>

        <li>
            <a href="saved_trips.php">
                My Saved Trips
            </a>
        </li>

    </ul>

</nav>


<!-- ================= HERO ================= -->

<section class="hero">

    <div class="hero-content">

        <h1>
            ✈️ Travel Made Personal
        </h1>

        <p>
            Discover the world, plan your perfect journey,
            and create unforgettable memories with Travel Hub.
        </p>

    </div>

</section>


<!-- ================= MISSION ================= -->

<section class="section">

    <div class="container">

        <div class="mission-box">

            <h2>
                🎯 Our Mission
            </h2>

            <p>
                Our mission is to make travel planning simple,
                personalized and enjoyable. Travel Hub brings
                destinations, famous tourist places, accommodation,
                food, transportation and activities together in one
                convenient platform.
            </p>

        </div>

    </div>

</section>


<!-- ================= HOW IT WORKS ================= -->

<section class="section">

    <div class="container">

        <h2 class="section-title">
            🧭 How Travel Hub Works
        </h2>

        <p class="section-subtitle">
            Planning your dream vacation is easy.
            Just follow these simple steps.
        </p>

        <div class="steps">

            <div class="step">
                <div class="step-icon">🌍</div>
                <h3>Discover</h3>
                <p>
                    Explore amazing countries
                    and destinations.
                </p>
            </div>

            <div class="step">
                <div class="step-icon">🎨</div>
                <h3>Customize</h3>
                <p>
                    Select your stay, food,
                    transport and activities.
                </p>
            </div>

            <div class="step">
                <div class="step-icon">✨</div>
                <h3>Generate</h3>
                <p>
                    Generate your personalized
                    day-by-day trip plan.
                </p>
            </div>

            <div class="step">
                <div class="step-icon">💾</div>
                <h3>Save</h3>
                <p>
                    Save your trip plan for
                    future reference.
                </p>
            </div>

            <div class="step">
                <div class="step-icon">❤️</div>
                <h3>Explore</h3>
                <p>
                    Turn your plan into
                    beautiful memories.
                </p>
            </div>

        </div>

    </div>

</section>


<!-- ================= WHY CHOOSE US ================= -->

<section class="section">

    <div class="container">

        <h2 class="section-title">
            ⭐ Why Choose Travel Hub?
        </h2>

        <p class="section-subtitle">
            Everything you need to plan your perfect
            vacation is available in one place.
        </p>

        <div class="features">

            <div class="feature">
                <div class="feature-icon">🌎</div>

                <h3>
                    Explore Destinations
                </h3>

                <p>
                    Discover countries and famous
                    tourist attractions.
                </p>
            </div>

            <div class="feature">
                <div class="feature-icon">🗺️</div>

                <h3>
                    Smart Itinerary
                </h3>

                <p>
                    Get a day-by-day personalized
                    travel itinerary.
                </p>
            </div>

            <div class="feature">
                <div class="feature-icon">🏨</div>

                <h3>
                    Stay Options
                </h3>

                <p>
                    Choose accommodation according
                    to your preference.
                </p>
            </div>

            <div class="feature">
                <div class="feature-icon">🍜</div>

                <h3>
                    Food & Activities
                </h3>

                <p>
                    Select food preferences and
                    exciting activities.
                </p>
            </div>

        </div>

    </div>

</section>


<!-- ================= HIGHLIGHTS ================= -->

<section class="section highlights">

    <div class="container">

        <h2 class="section-title">
            📊 Travel Hub Highlights
        </h2>

        <p class="section-subtitle">
            Built to make your travel planning
            experience easier.
        </p>

        <div class="highlight-grid">

            <div class="highlight">
                <div class="highlight-icon">🌍</div>
                <h3>10+</h3>
                <p>Destinations</p>
            </div>

            <div class="highlight">
                <div class="highlight-icon">📍</div>
                <h3>40+</h3>
                <p>Tourist Places</p>
            </div>

            <div class="highlight">
                <div class="highlight-icon">✈️</div>
                <h3>1</h3>
                <p>Personalized Trip Planner</p>
            </div>

            <div class="highlight">
                <div class="highlight-icon">💾</div>
                <h3>∞</h3>
                <p>Saved Trip Plans</p>
            </div>

        </div>

    </div>

</section>


<!-- ================= QUOTE ================= -->

<section class="quote">

    <div class="container">

        <div class="quote-text">

            “Travel is not just about the places
            you visit, but the memories you create
            along the way.”

        </div>

        <div class="quote-author">

            🌍 Explore • Plan • Travel • Remember ❤️

        </div>

    </div>

</section>


<!-- ================= EXPLORE DESTINATIONS ================= -->

<section class="explore-section">

    <h2>
        🌍 Explore Our Destinations
    </h2>

    <p>
        Discover beautiful countries, famous tourist places,
        amazing experiences and find your next adventure.
    </p>

    <a href="destinations.php" class="explore-btn">
        🌍 Explore Destinations
    </a>

</section>


<!-- ================= FOOTER ================= -->

<footer class="footer">

    <p>
        🌍 Travel Hub
    </p>

    <p>
        Explore • Plan • Travel • Remember ❤️
    </p>

    <p>
        © <?php echo date("Y"); ?> Travel Hub. All Rights Reserved.
    </p>

</footer>


</body>

</html>