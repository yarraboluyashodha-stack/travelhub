<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Travel Hub - Explore The World</title>

<style>

/* ================= GENERAL ================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f5f9ff;
    color: #333;
    line-height: 1.6;
}

a {
    text-decoration: none;
}


/* ================= NAVIGATION ================= */

.navbar {

    background: linear-gradient(
        135deg,
        #007bff,
        #00b4d8
    );

    min-height: 65px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 7%;

    box-shadow: 0 3px 12px rgba(0,0,0,0.15);

    position: sticky;

    top: 0;

    z-index: 1000;
}

.logo {

    color: white;

    font-size: 23px;

    font-weight: bold;
}

.nav-links {

    display: flex;

    align-items: center;

    gap: 22px;
}

.nav-links a {

    color: white;

    font-size: 15px;

    font-weight: 600;

    transition: 0.3s;
}

.nav-links a:hover {

    color: #e8f7ff;

    transform: translateY(-1px);
}


/* ================= HERO ================= */

.hero {

    min-height: 570px;

    background:

        linear-gradient(
            rgba(0, 70, 140, 0.55),
            rgba(0, 0, 0, 0.45)
        ),

        url("images/home.jpg");

    background-size: cover;

    background-position: center;

    display: flex;

    align-items: center;

    justify-content: center;

    text-align: center;

    color: white;

    padding: 50px 20px;
}

.hero-content {

    max-width: 900px;
}

.hero h1 {

    font-size: 58px;

    margin-bottom: 20px;

    text-shadow: 2px 3px 8px rgba(0,0,0,0.3);
}

.hero h2 {

    font-size: 30px;

    margin-bottom: 15px;

    font-weight: normal;
}

.hero p {

    font-size: 19px;

    max-width: 750px;

    margin: 0 auto 30px;
}


/* HERO BUTTONS */

.hero-buttons {

    display: flex;

    justify-content: center;

    gap: 15px;

    flex-wrap: wrap;
}

.hero-btn {

    display: inline-block;

    padding: 15px 28px;

    border-radius: 10px;

    font-weight: bold;

    font-size: 16px;

    transition: 0.3s;
}

.explore-btn {

    background: white;

    color: #007bff;
}

.plan-btn {

    border: 2px solid white;

    color: white;

    background: transparent;
}

.hero-btn:hover {

    transform: translateY(-4px);

    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}


/* ================= SEARCH ================= */

.search-section {

    width: 90%;

    max-width: 850px;

    margin: -45px auto 0;

    position: relative;

    z-index: 5;
}

.search-box {

    background: white;

    padding: 25px;

    border-radius: 18px;

    box-shadow: 0 8px 30px rgba(0,0,0,0.12);

    text-align: center;
}

.search-box h2 {

    color: #007bff;

    margin-bottom: 15px;
}

.search-form {

    display: flex;

    gap: 10px;
}

.search-form input {

    flex: 1;

    padding: 14px;

    border: 1px solid #ddd;

    border-radius: 8px;

    font-size: 16px;

    outline: none;
}

.search-form input:focus {

    border-color: #007bff;
}

.search-form button {

    padding: 14px 25px;

    border: none;

    border-radius: 8px;

    background: #007bff;

    color: white;

    font-weight: bold;

    cursor: pointer;
}


/* ================= SECTIONS ================= */

.section {

    padding: 75px 0;
}

.container {

    width: 90%;

    max-width: 1100px;

    margin: auto;
}

.section-title {

    text-align: center;

    font-size: 35px;

    color: #007bff;

    margin-bottom: 15px;
}

.section-subtitle {

    text-align: center;

    color: #666;

    max-width: 750px;

    margin: 0 auto 45px;
}


/* ================= EXPERIENCES ================= */

.experiences {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 22px;
}

.experience {

    background: white;

    padding: 30px 20px;

    text-align: center;

    border-radius: 18px;

    box-shadow: 0 6px 22px rgba(0,0,0,0.08);

    transition: 0.3s;
}

.experience:hover {

    transform: translateY(-8px);
}

.experience-icon {

    font-size: 45px;

    margin-bottom: 15px;
}

.experience h3 {

    color: #007bff;

    margin-bottom: 10px;
}

.experience p {

    color: #666;

    font-size: 14px;
}


/* ================= HOW IT WORKS ================= */

.steps {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 20px;
}

.step {

    background: white;

    text-align: center;

    padding: 30px 20px;

    border-radius: 18px;

    box-shadow: 0 6px 22px rgba(0,0,0,0.08);

    position: relative;
}

.step-number {

    position: absolute;

    top: 12px;

    right: 15px;

    width: 30px;

    height: 30px;

    border-radius: 50%;

    background: #007bff;

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    font-weight: bold;
}

.step-icon {

    font-size: 42px;

    margin-bottom: 15px;
}

.step h3 {

    color: #007bff;

    margin-bottom: 10px;
}

.step p {

    color: #666;

    font-size: 14px;
}


/* ================= WHY CHOOSE US ================= */

.why-section {

    background: #eef7ff;
}

.why-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 22px;
}

.why-card {

    background: white;

    padding: 28px;

    border-radius: 16px;

    text-align: center;

    box-shadow: 0 5px 18px rgba(0,0,0,0.07);
}

.why-card-icon {

    font-size: 40px;

    margin-bottom: 12px;
}

.why-card h3 {

    color: #007bff;

    margin-bottom: 8px;
}

.why-card p {

    color: #666;

    font-size: 14px;
}


/* ================= TRAVEL INSPIRATION ================= */

.inspiration {

    background:

        linear-gradient(
            rgba(0,123,255,0.9),
            rgba(0,180,216,0.9)
        );

    color: white;

    text-align: center;

    padding: 75px 20px;
}

.inspiration h2 {

    font-size: 36px;

    margin-bottom: 15px;
}

.inspiration > p {

    max-width: 700px;

    margin: 0 auto 40px;
}

.inspiration-grid {

    max-width: 1000px;

    margin: auto;

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 20px;
}

.inspiration-card {

    background: rgba(255,255,255,0.15);

    border: 1px solid rgba(255,255,255,0.35);

    padding: 25px;

    border-radius: 15px;

    backdrop-filter: blur(5px);
}

.inspiration-card h3 {

    font-size: 21px;

    margin-bottom: 10px;
}


/* ================= FINAL CTA ================= */

.final-cta {

    background: white;

    text-align: center;

    padding: 75px 20px;
}

.final-cta h2 {

    color: #007bff;

    font-size: 38px;

    margin-bottom: 15px;
}

.final-cta p {

    color: #666;

    font-size: 17px;

    margin-bottom: 25px;
}

.final-btn {

    display: inline-block;

    padding: 15px 30px;

    background: linear-gradient(
        135deg,
        #007bff,
        #00b4d8
    );

    color: white;

    border-radius: 10px;

    font-weight: bold;
}

.final-btn:hover {

    opacity: 0.9;

    transform: translateY(-3px);
}


/* ================= FOOTER ================= */

.footer {

    background: #111827;

    color: white;

    text-align: center;

    padding: 28px;
}

.footer p {

    margin: 5px;
}


/* ================= MOBILE ================= */

@media(max-width: 900px) {

    .nav-links {

        gap: 10px;
    }

    .nav-links a {

        font-size: 12px;
    }

    .hero h1 {

        font-size: 42px;
    }

    .experiences {

        grid-template-columns: repeat(2, 1fr);
    }

    .steps {

        grid-template-columns: repeat(2, 1fr);
    }

    .why-grid {

        grid-template-columns: repeat(2, 1fr);
    }

    .inspiration-grid {

        grid-template-columns: repeat(2, 1fr);
    }

}


@media(max-width: 600px) {

    .navbar {

        flex-direction: column;

        padding: 15px;

        gap: 15px;
    }

    .nav-links {

        flex-wrap: wrap;

        justify-content: center;
    }

    .hero {

        min-height: 500px;
    }

    .hero h1 {

        font-size: 34px;
    }

    .hero h2 {

        font-size: 23px;
    }

    .hero p {

        font-size: 16px;
    }

    .search-form {

        flex-direction: column;
    }

    .experiences,
    .steps,
    .why-grid,
    .inspiration-grid {

        grid-template-columns: 1fr;
    }

    .section-title {

        font-size: 29px;
    }

}

</style>

</head>


<body>


<!-- ================= NAVIGATION ================= -->

<nav class="navbar">

    <a href="index.php" class="logo">
        🌍 Travel Hub
    </a>

    <div class="nav-links active" >

        <a href="index.php"  >
            Home
        </a>

        <a href="about.php">
            About
        </a>

        <a href="destinations.php">
            Destinations
        </a>

        <a href="contact.php">
            Contact
        </a>
        <a href="login.php">
            Login
        </a>

       

        <a href="register.php">
            Register
        </a>

        <a href="saved_trips.php">
            My Saved Trips
        </a>

    </div>

</nav>


<!-- ================= HERO ================= -->

<section class="hero">

    <div class="hero-content">

        <h2>
            🌎 Welcome to Travel Hub
        </h2>

        <h1>
            Your Journey Begins Here ✈️
        </h1>

        <p>
            Discover amazing places, find new experiences,
            plan your perfect journey and create memories
            that last a lifetime.
        </p>


        <div class="hero-buttons">

            <a
                href="destinations.php"
                class="hero-btn explore-btn"
            >
                🌍 Explore Destinations
            </a>


            

        </div>

    </div>

</section>





<!-- ================= TRAVEL EXPERIENCES ================= -->

<section class="section">

    <div class="container">

        <h2 class="section-title">
            🎨 Choose Your Travel Experience
        </h2>

        <p class="section-subtitle">
            Every traveller has a different dream.
            Choose the experience that inspires you.
        </p>


        <div class="experiences">


            <div class="experience">

                <div class="experience-icon">
                    🏖️
                </div>

                <h3>
                    Beach Escape
                </h3>

                <p>
                    Relax by beautiful beaches,
                    enjoy the ocean and experience
                    peaceful island life.
                </p>

            </div>


            <div class="experience">

                <div class="experience-icon">
                    🏔️
                </div>

                <h3>
                    Mountain Adventure
                </h3>

                <p>
                    Discover breathtaking mountains,
                    nature and exciting adventures.
                </p>

            </div>


            <div class="experience">

                <div class="experience-icon">
                    🏛️
                </div>

                <h3>
                    History & Culture
                </h3>

                <p>
                    Explore historic places,
                    traditions, architecture and culture.
                </p>

            </div>


            <div class="experience">

                <div class="experience-icon">
                    🍜
                </div>

                <h3>
                    Food & Local Life
                </h3>

                <p>
                    Taste local food and discover
                    unique cultural experiences.
                </p>

            </div>


            <div class="experience">

                <div class="experience-icon">
                    🛍️
                </div>

                <h3>
                    Shopping & City Life
                </h3>

                <p>
                    Experience vibrant cities,
                    shopping streets and modern life.
                </p>

            </div>


            <div class="experience">

                <div class="experience-icon">
                    🌃
                </div>

                <h3>
                    Nightlife
                </h3>

                <p>
                    Enjoy exciting evenings,
                    entertainment and city lights.
                </p>

            </div>


        </div>

    </div>

</section>


<!-- ================= HOW IT WORKS ================= -->

<section class="section">

    <div class="container">

        <h2 class="section-title">
            🧭 How Travel Hub Works
        </h2>

        <p class="section-subtitle">
            Plan your next adventure in just a few simple steps.
        </p>


        <div class="steps">


            <div class="step">

                <div class="step-number">
                    1
                </div>

                <div class="step-icon">
                    🌍
                </div>

                <h3>
                    Discover
                </h3>

                <p>
                    Explore countries and
                    famous tourist places.
                </p>

            </div>


            <div class="step">

                <div class="step-number">
                    2
                </div>

                <div class="step-icon">
                    🎨
                </div>

                <h3>
                    Customize
                </h3>

                <p>
                    Choose your stay, food,
                    transport and activities.
                </p>

            </div>


            <div class="step">

                <div class="step-number">
                    3
                </div>

                <div class="step-icon">
                    ✨
                </div>

                <h3>
                    Generate
                </h3>

                <p>
                    Create your personalized
                    day-by-day itinerary.
                </p>

            </div>


            <div class="step">

                <div class="step-number">
                    4
                </div>

                <div class="step-icon">
                    💾
                </div>

                <h3>
                    Save
                </h3>

                <p>
                    Save your trip plan and
                    access it later.
                </p>

            </div>


        </div>

    </div>

</section>


<!-- ================= WHY TRAVEL HUB ================= -->

<section class="section why-section">

    <div class="container">

        <h2 class="section-title">
            💎 Why Choose Travel Hub?
        </h2>

        <p class="section-subtitle">
            We bring the important parts of travel planning
            together in one simple platform.
        </p>


        <div class="why-grid">


            <div class="why-card">

                <div class="why-card-icon">
                    🌎
                </div>

                <h3>
                    Multiple Destinations
                </h3>

                <p>
                    Explore different countries
                    and discover amazing places.
                </p>

            </div>


            <div class="why-card">

                <div class="why-card-icon">
                    🗺️
                </div>

                <h3>
                    Personalized Plans
                </h3>

                <p>
                    Create an itinerary based
                    on your preferences.
                </p>

            </div>


            <div class="why-card">

                <div class="why-card-icon">
                    🏨
                </div>

                <h3>
                    Stay Preferences
                </h3>

                <p>
                    Select the accommodation
                    style that suits you.
                </p>

            </div>


            <div class="why-card">

                <div class="why-card-icon">
                    🍜
                </div>

                <h3>
                    Food Choices
                </h3>

                <p>
                    Choose food preferences
                    for your journey.
                </p>

            </div>


            <div class="why-card">

                <div class="why-card-icon">
                    🚗
                </div>

                <h3>
                    Transport Options
                </h3>

                <p>
                    Select transportation
                    according to your trip.
                </p>

            </div>


            <div class="why-card">

                <div class="why-card-icon">
                    💾
                </div>

                <h3>
                    Save Your Trips
                </h3>

                <p>
                    Keep your generated travel
                    plans for future reference.
                </p>

            </div>


        </div>

    </div>

</section>


<!-- ================= TRAVEL INSPIRATION ================= -->

<section class="inspiration">

    <h2>
        💡 Find Your Travel Inspiration
    </h2>

    <p>
        Not sure what kind of trip you want?
        Let your interests guide your next adventure.
    </p>


    <div class="inspiration-grid">


        <div class="inspiration-card">

            <h3>
                🏖️ Love Beaches?
            </h3>

            <p>
                Discover peaceful beaches,
                islands and ocean adventures.
            </p>

        </div>


        <div class="inspiration-card">

            <h3>
                🏔️ Love Mountains?
            </h3>

            <p>
                Experience breathtaking views,
                nature and mountain adventures.
            </p>

        </div>


        <div class="inspiration-card">

            <h3>
                🏛️ Love History?
            </h3>

            <p>
                Walk through historic places,
                monuments and ancient cultures.
            </p>

        </div>


        <div class="inspiration-card">

            <h3>
                🍜 Love Food?
            </h3>

            <p>
                Taste local dishes and discover
                unique food traditions.
            </p>

        </div>


        <div class="inspiration-card">

            <h3>
                🛍️ Love Shopping?
            </h3>

            <p>
                Explore famous shopping streets,
                markets and modern malls.
            </p>

        </div>


        <div class="inspiration-card">

            <h3>
                🌃 Love Nightlife?
            </h3>

            <p>
                Enjoy beautiful city lights,
                entertainment and nightlife.
            </p>

        </div>


    </div>

</section>


<!-- ================= FINAL CTA ================= -->

<section class="final-cta">

    <h2>
        🌍 Ready To Explore The World?
    </h2>
    <p>
        Your next adventure is waiting.
        Discover your dream destination today.
    </p>

    <a
        href="destinations.php"
        class="final-btn"
    >
        🌍 Explore Destinations
    </a>

</section>


<!-- ================= FOOTER ================= -->

<footer class="footer">

    <p>
        🌍 Travel Hub
    </p>

    <p>
        Explore • Plan • Travel • Remember ❤️
    </p>

    <p>
        © <?php echo date("Y"); ?> Travel Hub.
        All Rights Reserved.
    </p>

</footer>


</body>

</html>