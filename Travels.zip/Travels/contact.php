<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact - Travel Hub</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        body {
            margin: 0;
            background-color: #f5f9ff;
            font-family: Arial, sans-serif;
        }

        /* Navbar */
        .navbar {
            padding: 15px 0;
        }

        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
        }

        .menu {
            display: flex;
            flex-direction: row;
            align-items: center;
            margin-left: auto;
        }

        .menu a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-size: 16px;
        }

        /* Contact */
        .contact-section {
            padding: 70px 20px;
            text-align: center;
        }

        .contact-box {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 45px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.10);
        }

        .contact-box h1 {
            color: #0d6efd;
            margin-bottom: 35px;
        }

        /* Social Logos */
        .social-logos {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 45px;
            margin-bottom: 40px;
        }

        .social-logos a {
            text-decoration: none;
        }

        .social-logos i {
            font-size: 55px;
        }

        .instagram {
            color: #E4405F;
        }

        .facebook {
            color: #1877F2;
        }

        .whatsapp {
            color: #25D366;
        }

        /* Contact Numbers */
        .phone {
            font-size: 22px;
            font-weight: bold;
            margin: 15px 0;
        }

        .phone-title {
            color: #0d6efd;
            margin-bottom: 20px;
        }

        /* Mobile */
        @media (max-width: 768px) {

            .menu {
                flex-wrap: wrap;
                justify-content: center;
            }

            .menu a {
                margin: 5px 10px;
            }

            .social-logos {
                gap: 30px;
            }

            .social-logos i {
                font-size: 45px;
            }
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">

            <a class="navbar-brand" href="index.php">
               🌍 Travel hub
            </a>

            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarMenu">

                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMenu">

                <ul class="navbar-nav ms-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="destinations.php">
                            Destinations
                        </a>
                    </li>

                    <li class="nav-item ">
                        <a class="nav-link active" href="contact.php">
                            Contact
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="login.php">
                         Login
                        </a>
                    </li>

                    
                    <li class="nav-item">
                        <a class="nav-link" href="enquiry.php">
                            Register
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saved_trips.php">My Saved Trips

                        </a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>


    <!-- Contact Section -->
    <section class="contact-section">

        <div class="contact-box">

            <h1>Contact Us 📞</h1>

            <!-- Only Logos -->
            <div class="social-logos">

                <a href="#" class="instagram">
                    <i class="fa-brands fa-instagram"></i>
                </a>

                <a href="#" class="facebook">
                    <i class="fa-brands fa-facebook"></i>
                </a>

                <a href="#" class="whatsapp">
                    <i class="fa-brands fa-whatsapp"></i>
                </a>

            </div>

            <!-- Contact Numbers -->
            <h3 class="phone-title">Contact Numbers</h3>

            <div class="phone">
                📞 +91 98765 43210
            </div>

            <div class="phone">
                📞 +91 91234 56789
            </div>

        </div>

    </section>

</body>
</html>