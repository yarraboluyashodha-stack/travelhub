<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $country = $_POST["country"];
    $days = $_POST["days"];
    $adults = $_POST["adults"];
    $children = $_POST["children"];
    $hotel = $_POST["hotel"];
    $food = $_POST["food"];
    $transport = $_POST["transport"];
    $budget = $_POST["budget"];

    $activities = isset($_POST["activities"])
        ? $_POST["activities"]
        : [];

    $places = isset($_POST["places"])
        ? $_POST["places"]
        : [];

    $filename = "trip_" . date("Ymd_His") . ".html";

    $folder = "saved_trips/";

    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    $activityText = !empty($activities)
        ? implode(" • ", array_map("htmlspecialchars", $activities))
        : "No activities selected";

    $placeText = !empty($places)
        ? implode(" • ", array_map("htmlspecialchars", $places))
        : "No places selected";

    $html = "
<!DOCTYPE html>
<html>
<head>

<meta charset='UTF-8'>

<title>My Trip Plan - $country</title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #f4f7fb;
    margin: 0;
    padding: 30px;
}

.container {
    max-width: 800px;
    margin: auto;
    background: white;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

h1 {
    text-align: center;
    color: #007bff;
}

.info {
    background: #f1f7ff;
    padding: 15px;
    margin: 10px 0;
    border-radius: 8px;
}

h2 {
    color: #007bff;
}

</style>

</head>

<body>

<div class='container'>

<h1>✈️ My Trip Plan</h1>

<h2>🌍 $country</h2>

<div class='info'>
📅 <strong>Duration:</strong> $days Days
</div>

<div class='info'>
👨‍👩‍👧 <strong>Travellers:</strong> $adults Adults, $children Children
</div>

<div class='info'>
🏨 <strong>Hotel:</strong> $hotel
</div>

<div class='info'>
🍜 <strong>Food:</strong> $food
</div>

<div class='info'>
🚗 <strong>Transport:</strong> $transport
</div>

<div class='info'>
💰 <strong>Budget:</strong> $budget
</div>

<h2>🎯 Selected Activities</h2>

<p>$activityText</p>

<h2>📍 Suggested Places</h2>

<p>$placeText</p>

<hr>

<p style='text-align:center;'>
✨ Created using Travel & Tourism Trip Planner
</p>

</div>

</body>
</html>
";

    file_put_contents($folder . $filename, $html);

    echo "
    <script>
        alert('🎉 Your trip plan has been saved successfully!');
        window.location.href = 'saved_trips/$filename';
    </script>
    ";
}
?>